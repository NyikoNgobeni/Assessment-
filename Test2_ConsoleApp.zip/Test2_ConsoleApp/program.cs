﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Test2_ConsoleApp
{
    class program
    {
       
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
